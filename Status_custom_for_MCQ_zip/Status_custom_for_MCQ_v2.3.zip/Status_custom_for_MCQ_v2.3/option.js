// デバックモード
const debugMode = "無効";

//##############################################################//

// ランキングで、50レベル以上を表示するかどうか
const RankingOverLevelDispley = "有効";

// ステータス画面で、50レベル以上を表示するかどうか
const StatusOverLevelDispley = "有効";

// 次のレベルまでに必要な経験値を表示するかどうか
const nextLevelExpDisplay = "有効";

// HPとMPのメーターを表示するかどうか
const HP_MP_meterDisplay = "有効";

// HPとMPのアラート用の色変更をするかどうか
const HP_MP_Alart = "有効";

// 武器と防具の耐久値のメーターを表示するかどうか
const Weapon_Armer_meterDisplay = "有効";

// 武器と防具の耐久値のアラート用の色変更をするかどうか
const Weapon_Armer_Alart = "有効";

// アイテム数アラート用の色変更をするかどうか
const ItemAlart = "有効";

// 周年記念日までのカウントダウンを表示するかどうか
const anniversaryCountdownDisplay = "有効";

//##############################################################//

// EXtext_before は追加レベルの数値の前に入る文字
// EXtext_after は追加レベルの数値の後に入る文字

// EXtext_exp_before は必要経験値の数値の前に入る文字
// EXtext_exp_after は必要経験値の数値の後に入る文字

// EXtext_exp2_before は必要経験値の数値の前に入る文字
// EXtext_exp2_after は必要経験値の数値の後に入る文字

const EXtext_before = "＋";
const EXtext_after = "";

const EXtext_exp_before = " あと";
const EXtext_exp_after = "";

const EXtext_exp2_before = " あと";
const EXtext_exp2_after = "";